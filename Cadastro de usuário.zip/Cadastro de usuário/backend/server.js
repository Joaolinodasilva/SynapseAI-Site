// server.js

const express = require('express');
const cors = require('cors'); 
const app = express();
const port = 3000;

// Configuração do Middleware
// 1. Permite o servidor processar dados JSON
app.use(express.json());

// 2. Permite a comunicação entre diferentes domínios (CORS)
app.use(cors({
    origin: '*' // Permite o acesso do GitHub Pages (frontend) ao backend
})); 

// *************************************************************
// ROTA DE STATUS CHECK (ADICIONADA)
// *************************************************************
// Responde à requisição GET na raiz (/) do navegador.
app.get('/', (req, res) => {
    res.send('Servidor Synapse AI Backend está OK e pronto para o chatbot!');
});
// *************************************************************


// *************************************************************
// Lógica de IA Simplificada para o Chatbot
// *************************************************************
function processarMensagemComIA(mensagemUsuario) {
    const msg = mensagemUsuario.toLowerCase();

    // 1. Intent: Preços e Planos
    if (msg.includes("preço") || msg.includes("custo") || msg.includes("plano")) {
        return "Nossos planos são baseados na complexidade do seu sistema e no volume de logs. Temos um gerador de orçamento em nossa área do cliente. Quer o link?";
    } 
    // 2. Intent: Problemas/Falhas (Análise Preditiva)
    else if (msg.includes("falha") || msg.includes("instabilidade") || msg.includes("erro")) {
        return "Nossos modelos de IA detectaram uma anomalia em sua região. Por favor, forneça seu código de sistema para iniciarmos uma análise preditiva e preventiva imediata.";
    } 
    // 3. Intent: Otimização/Eficiência
    else if (msg.includes("otimizar") || msg.includes("eficiência") || msg.includes("recursos")) {
        return "Nossa IA de otimização pode reduzir seus custos de cloud em até 30%. Por favor, agende uma demonstração gratuita com um de nossos engenheiros.";
    } 
    // 4. Intent: Saudação
    else if (msg.includes("oi") || msg.includes("olá") || msg.includes("bom dia")) {
        return "Olá! Sou o Synapse Bot, seu assistente de IA para estabilidade de sistemas. Como posso te ajudar hoje?";
    } 
    // 5. Intent: Fallback (Resposta Padrão)
    else {
        return "Não entendi bem. Posso te conectar a um especialista em sistemas, ou você pode tentar digitar 'preço' ou 'falha' para obter uma resposta direcionada.";
    }
}
// *************************************************************


// Rota POST principal para o chatbot
app.post('/api/chatbot', (req, res) => {
    const mensagemUsuario = req.body.mensagem;

    if (!mensagemUsuario) {
        return res.status(400).json({ resposta: 'Mensagem inválida fornecida.' });
    }

    // Processa a mensagem e obtém a resposta da "IA"
    const respostaIA = processarMensagemComIA(mensagemUsuario);

    // Envia a resposta de volta ao frontend
    res.json({ resposta: respostaIA });
});

// Inicia o servidor Node.js
app.listen(port, () => {
    console.log(`Servidor Node.js rodando em http://localhost:${port}`);
    console.log('Backend do Chatbot pronto.');
});